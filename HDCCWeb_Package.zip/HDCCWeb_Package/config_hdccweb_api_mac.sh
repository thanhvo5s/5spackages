#!/bin/bash

echo "Docx template folder: $HOME/HDCCWeb"

# Chạy file thực thi api-mac (giả sử là tương đương api-win.exe)
./dist/api-macos

# Dừng màn hình bằng cách chờ người dùng nhấn Enter
read -p "Press Enter to continue..."
