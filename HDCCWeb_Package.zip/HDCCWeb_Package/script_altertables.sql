USE CongChungDB;

ALTER TABLE `congchungdb`.`hopdong_canho` 
CHANGE COLUMN `GiaTriHopDong` `GiaTriHopDong` DECIMAL(18,2) NULL DEFAULT '0' ,
CHANGE COLUMN `TienThuLao` `TienThuLao` DECIMAL(18,2) NULL DEFAULT NULL ;

ALTER TABLE `congchungdb`.`hopdong_dat` 
CHANGE COLUMN `GiaTriHopDong` `GiaTriHopDong` DECIMAL(18,2) NULL DEFAULT '0' ,
CHANGE COLUMN `TienThuLao` `TienThuLao` DECIMAL(18,2) NULL DEFAULT NULL ;

ALTER TABLE `congchungdb`.`hopdong_xe` 
CHANGE COLUMN `GiaTriHopDong` `GiaTriHopDong` DECIMAL(18,2) NULL DEFAULT '0' ;

ALTER TABLE `congchungdb`.`taisan_canho` 
CHANGE COLUMN `DienTichCanHo` `DienTichCanHo` DECIMAL(18,2) NULL DEFAULT NULL ,
CHANGE COLUMN `DienTichXayDung` `DienTichXayDung` DECIMAL(18,2) NULL DEFAULT NULL ,
CHANGE COLUMN `DienTichSoHuuChung` `DienTichSoHuuChung` DECIMAL(18,2) NULL DEFAULT NULL ,
CHANGE COLUMN `DienTichSoHuuRieng` `DienTichSoHuuRieng` DECIMAL(18,2) NULL DEFAULT NULL ;

ALTER TABLE `congchungdb`.`taisan_dat` 
CHANGE COLUMN `DienTichSuDungRieng` `DienTichSuDungRieng` DECIMAL(18,2) NULL DEFAULT NULL ,
CHANGE COLUMN `DienTichSuDungChung` `DienTichSuDungChung` DECIMAL(18,2) NULL DEFAULT NULL ,
CHANGE COLUMN `TongDienTich` `TongDienTich` DECIMAL(18,2) NULL DEFAULT NULL ,
CHANGE COLUMN `DienTichXayDung` `DienTichXayDung` DECIMAL(18,2) NULL DEFAULT NULL ,
CHANGE COLUMN `DienTichSan` `DienTichSan` DECIMAL(18,2) NULL DEFAULT NULL ,
CHANGE COLUMN `DonGiaCongTrinh` `DonGiaCongTrinh` DECIMAL(18,2) NULL DEFAULT NULL ,
CHANGE COLUMN `DonGiaThucTeChuyenGiao` `DonGiaThucTeChuyenGiao` DECIMAL(18,2) NULL DEFAULT NULL ;

ALTER TABLE `congchungdb`.`hopdong_xe` 
CHANGE COLUMN `LoaiHopDong` `LoaiHopDong` ENUM('MuaBanXe', 'ChoTangXe', 'UyQuyenXe', 'ChoThueXe') NOT NULL ;

ALTER TABLE `congchungdb`.`cauhinh_vanphongcongchung` 
ADD COLUMN `DefaultCCVForAllContract` TINYINT NULL DEFAULT NULL AFTER `NgayCapNhat`;

ALTER TABLE `congchungdb`.`hopdong_dat` 
CHANGE COLUMN `LoaiHopDong` `LoaiHopDong` ENUM('ChuyenNhanQuyenSuDungDat', 'ChuyenNhanQuyenSuDungDatVaTaiSanGanLien', 'ChoTangQuyenSuDungDat', 'ChoTangTaiSanGanLien', 'ChoTangQuyenSuDungDatVaTaiSanGanLien', 'ThueQuyenSuDungDat', 'ThueQuyenSuDungDatVaTaiSanGanLien', 'ChiChoThueTaiSanGanLienVoiDat') NOT NULL ;
