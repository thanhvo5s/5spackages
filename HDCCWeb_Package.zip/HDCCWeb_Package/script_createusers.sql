USE CongChungDB;
-- Tạo người quản trị mặc định (Quyền: 'QuanTri') tên đăng nhập là admin với mật khẩu '12345'
INSERT INTO NguoiDung 
    (TenDangNhap, MatKhau, QuyenHan, HoVaTen, Email, DienGiai, NguoiTao, NguoiCapNhat, NgayTao, NgayCapNhat)
VALUES 
    ('admin', SHA2('12345', 256), 'QuanTri', 'Trần Văn Hoàng', 'admin@example.com', 'Admin user', 1, 1, NOW(), NOW());

-- Tạo nhân viên mặc định (Quyền: 'NhanVien') tên đăng nhập là nhanvien01 với mật khẩu '123'
INSERT INTO NguoiDung 
    (TenDangNhap, MatKhau, QuyenHan, HoVaTen, Email, DienGiai, NguoiTao, NguoiCapNhat, NgayTao, NgayCapNhat)
VALUES 
    ('nhanvien01', SHA2('123', 256), 'NhanVien', 'Lê Thanh Tú', 'employee@example.com', 'Employee user', 1, 1, NOW(), NOW());