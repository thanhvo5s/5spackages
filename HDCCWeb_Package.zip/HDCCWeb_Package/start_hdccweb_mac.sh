serve -s build
read -p "Press Enter to continue..."