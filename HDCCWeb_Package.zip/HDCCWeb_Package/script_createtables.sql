USE CongChungDB;

----------------------------------------------------------------
-- 1. BẢNG KHACH_HANG_CANHAN
----------------------------------------------------------------
CREATE TABLE KhachHangCaNhan (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    HoVaTen VARCHAR(255) NOT NULL,
    SoCanCuocCongDan VARCHAR(20) NOT NULL UNIQUE,
    GioiTinh ENUM('Nam','Nu') NULL,
    QuocTich VARCHAR(100) NULL,
    SoTaiKhoanNganHang VARCHAR(50) NULL,
    TenNganHang VARCHAR(255) NULL,
    MaSoThue VARCHAR(20) NULL,
    NgheNghiep VARCHAR(255) NULL,
    NoiSinh VARCHAR(255) NULL,
    NgaySinh DATE NULL,
    DiaChi VARCHAR(255) NULL,
    QuanHuyen VARCHAR(100) NULL,
    TinhThanhPho VARCHAR(100) NULL,
    SoDienThoai VARCHAR(20) NULL,
    SoFax VARCHAR(20) NULL,
    Email VARCHAR(255) NULL,
    NgayCapCanCuoc DATE NULL,
    NoiCapCanCuoc VARCHAR(255) NULL,
    SoHoChieu VARCHAR(50) NULL,
    NgayCapHoChieu DATE NULL,
    NoiCapHoChieu VARCHAR(255) NULL,
    DienGiai TEXT NULL,
    NguoiTao INT NOT NULL,
    NguoiCapNhat INT DEFAULT NULL,
    NgayTao DATETIME NOT NULL,
    NgayCapNhat DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

----------------------------------------------------------------
-- 2. BẢNG KHACH_HANG_TOCHUC
----------------------------------------------------------------
CREATE TABLE KhachHangToChuc (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    TenToChuc VARCHAR(255) NOT NULL,
    MaSoThue VARCHAR(20) NULL,
    DiaChi VARCHAR(255) NULL,
    SoTaiKhoanNganHang VARCHAR(50) NULL,
    TenNganHang VARCHAR(255) NULL,
    NguoiDaiDien VARCHAR(255) NULL,
    ChucVuNguoiDaiDien VARCHAR(255) NULL,
    DienThoaiToChuc VARCHAR(20) NULL,
    EmailToChuc VARCHAR(255) NULL,
    DienThoaiNguoiDaiDien VARCHAR(20) NULL,
    EmailNguoiDaiDien VARCHAR(255) NULL,
    DienGiai TEXT NULL,
    NguoiTao INT NOT NULL,
    NguoiCapNhat INT DEFAULT NULL,
    NgayTao DATETIME NOT NULL,
    NgayCapNhat DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

----------------------------------------------------------------
-- 3. BẢNG TAI_SAN_DAT (Đất và Tài sản gắn liền)
----------------------------------------------------------------
CREATE TABLE TaiSan_Dat (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    SoSo VARCHAR(50) NOT NULL,
    SoVaoSo VARCHAR(50) NULL,
    NgayCapSo DATE NULL,
    SoTo VARCHAR(20) NOT NULL,
    SoThua VARCHAR(20) NOT NULL,
    HinhThucSuDung VARCHAR(255) NULL,
    DienTichSuDungRieng FLOAT NULL,
    DienTichSuDungChung FLOAT NULL,
    MucDichSuDung VARCHAR(255) NULL,
    ThoiHanSuDung VARCHAR(50) NULL,
    NguonGocSuDung VARCHAR(255) NULL,
    ThongTinQuyenSuDungDat TEXT NULL,
    HanCheQuyenSuDungDat TEXT NULL,
    ThongTinTaiSanGanLien TEXT NULL,
    ThongTinQuyenSoHuuTaiSanGanLien TEXT NULL,
    GhiChuThuaDat TEXT NULL,
    TongDienTich FLOAT NULL,
    DiaChiThuaDat VARCHAR(255) NULL,
    SoNha VARCHAR(20) NULL,
    ToaNha VARCHAR(255) NULL,
    Hem VARCHAR(100) NULL,
    DuongPho VARCHAR(255) NULL,
    ThonXomAp VARCHAR(255) NULL,
    Phuong VARCHAR(100) NULL,
    Quan VARCHAR(100) NULL,
    TinhThanh VARCHAR(100) NULL,
    ViTriThuaDat VARCHAR(250) NULL,
    CapNha VARCHAR(50) NULL,
    LoaiNha VARCHAR(50) NULL,
    HangNha VARCHAR(50) NULL,
    DienTichXayDung FLOAT NULL,
    DienTichSan FLOAT NULL,
    HeSoCongTrinh VARCHAR(20) NULL,  -- thay đổi từ DECIMAL sang VARCHAR(20)
    DonGiaCongTrinh FLOAT NULL,
    DonGiaThucTeChuyenGiao FLOAT NULL,
    NamHoanCong YEAR NULL,
    GiaTriNha FLOAT NULL,
    GiaTriNhaDatThucTe FLOAT NULL,
    ChuCongTrinhNha VARCHAR(255) NULL,
    DiaChiChuDuAn VARCHAR(255) NULL,
    LoaiCongTrinh VARCHAR(50) NULL,
    HangCongTrinh VARCHAR(50) NULL,
    CapCongTrinh VARCHAR(50) NULL,
    NguonGocNha VARCHAR(255) NULL,
    TuXayDungHoacChuyenNhuong ENUM('TuXayDung','ChuyenNhuong') NULL,
    NamHoanThanh YEAR NULL,
    DienGiai TEXT NULL,
    NguoiTao INT NOT NULL,
    NguoiCapNhat INT DEFAULT NULL,
    NgayTao DATETIME NOT NULL,
    NgayCapNhat DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

----------------------------------------------------------------
-- 4. BẢNG TAI_SAN_CANHO
----------------------------------------------------------------
CREATE TABLE TaiSan_Canho (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    DiaChi VARCHAR(255) NULL,
    SoTang VARCHAR(5) NOT NULL,         -- lưu dưới dạng VARCHAR(5)
    SoCanHo VARCHAR(5) NOT NULL,          -- lưu dưới dạng VARCHAR(5)
    TongSoTangNhaChungCu INT NULL,
    DienTichCanHo FLOAT NULL,
    DienTichXayDung FLOAT NULL,
    KetCauCanHo VARCHAR(255) NULL,
    ThongTinQuyenSoHuuCanHo TEXT NULL,
    ThuaDatID INT NOT NULL,             -- tham chiếu đến bảng TaiSan_Dat
    KetCauDuAn VARCHAR(255) NULL,
    SoTangNoi VARCHAR(5) NULL,
    SoTangHam VARCHAR(5) NULL,
    ChuDuAn VARCHAR(255) NULL,
    DienTichSoHuuChung FLOAT NULL,
    DienTichSoHuuRieng FLOAT NULL,
    DiaChiDuAn VARCHAR(255) NULL,
    DienGiai TEXT NULL,
    NguoiTao INT NOT NULL,
    NguoiCapNhat INT DEFAULT NULL,
    NgayTao DATETIME NOT NULL,
    NgayCapNhat DATETIME NOT NULL,
    CONSTRAINT FK_TaiSan_Canho_ThuaDat FOREIGN KEY (ThuaDatID) REFERENCES TaiSan_Dat(ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

----------------------------------------------------------------
-- 5. BẢNG TAI_SAN_XE
----------------------------------------------------------------
CREATE TABLE TaiSan_Xe (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    LoaiXe VARCHAR(50) NULL,
    BienSo VARCHAR(20) NOT NULL,
    NhanHieuXe VARCHAR(100) NULL,
    MauXe VARCHAR(50) NULL,
    DungTichXiLanh VARCHAR(50) NULL,   -- thay đổi từ FLOAT sang VARCHAR(50)
    SoDangKy VARCHAR(50) NULL,
    NgayDangKy DATE NULL,
    DonViDangKy VARCHAR(255) NULL,
    NgayCapSoDangKy DATE NULL,
    NgayDangKyLanDau DATE NULL,
    NguoiDangKyLanDau VARCHAR(255) NULL,
    DiaChiCapLanDau VARCHAR(255) NULL,
    DacDiemKhac TEXT NULL,
    SoMay VARCHAR(50) NULL,
    SoKhung VARCHAR(50) NULL,
    DienGiai TEXT NULL,
    NguoiTao INT NOT NULL,
    NguoiCapNhat INT DEFAULT NULL,
    NgayTao DATETIME NOT NULL,
    NgayCapNhat DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

----------------------------------------------------------------
-- 6. BẢNG HOP_DONG_DAT (Hợp đồng – Đất và Tài sản gắn liền)
----------------------------------------------------------------
CREATE TABLE HopDong_Dat (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    LoaiHopDong ENUM(
      'ChuyenNhanQuyenSuDungDat', 
      'ChuyenNhanQuyenSuDungDatVaTaiSanGanLien', 
      'ChoTangQuyenSuDungDat', 
      'ChoTangQuyenSuDungDatVaTaiSanGanLien', 
      'ThueQuyenSuDungDat', 
      'ThueQuyenSuDungDatVaTaiSanGanLien', 
      'ChiChoThueTaiSanGanLienVoiDat'
    ) NOT NULL,
    BenMua JSON NOT NULL,
    BenBan JSON NOT NULL,
    TaiSanID INT NOT NULL,
    GiaTriHopDong FLOAT DEFAULT 0,
    TienThuLao FLOAT NULL,
    NgayHopDong DATE NOT NULL,
    SoHopDong VARCHAR(20) NULL,
    PhuongThucThanhToan VARCHAR(255) NULL,
    BenNopPhi VARCHAR(20) NULL,
    ThoiDiemGiaoTaiSan DATETIME NULL,
    SoCongChung VARCHAR(20) NULL,
    SoQuyenCongChung VARCHAR(20) NULL,
    CongChungVien VARCHAR(50) NULL,
    NgayCongChung DATE NULL,
    DaKyDangDau BOOLEAN NULL,
    ThoiHanThue VARCHAR(50) NULL,
    NgayBatDauThue DATE NULL,
    MucDichThue TEXT NULL,
    -- Các trường riêng đối với hợp đồng đất:
    SoGiayChungNhanSoHuuNha VARCHAR(50) NULL,
    DonViCapGiayChungNhan VARCHAR(255) NULL,
    NgayCapGiayChungNhan DATE NULL,
    NgayDangKyChuSoHuuNha DATE NULL,
    SoHopDongMuaBanNha VARCHAR(50) NULL,
    PhongCongChungHopDongMuaBanNha VARCHAR(200) NULL,
    NgayCongChungHopDongMuaBanNha DATE NULL,
    NgayDangKyHopDongMuaBanNha DATE NULL,
    NgayToKhaiTruocBa DATE NULL,
    ThoiHanUyQuyen VARCHAR(50) NULL,
    DienGiai TEXT NULL,
    NguoiTao INT NOT NULL,
    NguoiCapNhat INT DEFAULT NULL,
    NgayTao DATETIME NOT NULL,
    NgayCapNhat DATETIME NOT NULL,
    CONSTRAINT FK_HopDong_Dat_TaiSan FOREIGN KEY (TaiSanID) REFERENCES TaiSan_Dat(ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

----------------------------------------------------------------
-- 7. BẢNG HOP_DONG_CANHO (Hợp đồng – Căn hộ)
----------------------------------------------------------------
CREATE TABLE HopDong_Canho (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    LoaiHopDong ENUM('MuaBanCanHo','ChoTangCanHo','ChoThueCanHo','UyQuyenCanHo') NOT NULL,
    BenMua JSON NOT NULL,
    BenBan JSON NOT NULL,
    TaiSanID INT NOT NULL,
    GiaTriHopDong FLOAT DEFAULT 0,
    TienThuLao FLOAT NULL,
    NgayHopDong DATE NOT NULL,
    SoHopDong VARCHAR(20) NULL,
    PhuongThucThanhToan VARCHAR(255) NULL,
    BenNopPhi VARCHAR(20) NULL,
    ThoiDiemGiaoTaiSan DATETIME NULL,
    SoCongChung VARCHAR(20) NULL,
    SoQuyenCongChung VARCHAR(20) NULL,
    CongChungVien VARCHAR(50) NULL,
    NgayCongChung DATE NULL,
    DaKyDangDau BOOLEAN NULL,
    ThoiHanUyQuyen VARCHAR(50) NULL,
    ThoiHanThue VARCHAR(50) NULL,
    NgayBatDauThue DATE NULL,
    MucDichThue TEXT NULL,
    DienGiai TEXT NULL,
    NguoiTao INT NOT NULL,
    NguoiCapNhat INT DEFAULT NULL,
    NgayTao DATETIME NOT NULL,
    NgayCapNhat DATETIME NOT NULL,
    CONSTRAINT FK_HopDong_Canho_TaiSan FOREIGN KEY (TaiSanID) REFERENCES TaiSan_Canho(ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

----------------------------------------------------------------
-- 8. BẢNG HOP_DONG_XE (Hợp đồng – Xe)
----------------------------------------------------------------
CREATE TABLE HopDong_Xe (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    LoaiHopDong ENUM('MuaBanXe','ChoTangXe','UyQuyenXe') NOT NULL,
    BenMua JSON NOT NULL,
    BenBan JSON NOT NULL,
    TaiSanID INT NOT NULL,
    GiaTriHopDong FLOAT DEFAULT 0,
    NgayHopDong DATE NOT NULL,
    SoHopDong VARCHAR(20) NULL,
    PhuongThucThanhToan VARCHAR(255) NULL,
    BenNopPhi VARCHAR(20) NULL,
    ThoiDiemGiaoTaiSan DATETIME NULL,
    SoCongChung VARCHAR(20) NULL,
    SoQuyenCongChung VARCHAR(20) NULL,
    CongChungVien VARCHAR(50) NULL,
    NgayCongChung DATE NULL,
    DaKyDangDau BOOLEAN NULL,
    ThoiHanThue VARCHAR(50) NULL,
    NgayBatDauThue DATE NULL,
    MucDichThue TEXT NULL,
    CheDoThuLao VARCHAR(200) NULL,
    DieuKienTangChoXe VARCHAR(250) NULL,
    NgayCapSoDangKy DATE NULL,
    ThoaThuanGiaoXe TEXT NULL,
    ThoiHanUyQuyen VARCHAR(50) NULL,
    DienGiai TEXT NULL,
    NguoiTao INT NOT NULL,
    NguoiCapNhat INT DEFAULT NULL,
    NgayTao DATETIME NOT NULL,
    NgayCapNhat DATETIME NOT NULL,
    CONSTRAINT FK_HopDong_Xe_TaiSan FOREIGN KEY (TaiSanID) REFERENCES TaiSan_Xe(ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

----------------------------------------------------------------
-- 9. BẢNG CAU_HINH_VPCC (Cấu hình Văn phòng Công chứng)
----------------------------------------------------------------
CREATE TABLE CauHinh_VanPhongCongChung (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    TenVanPhong VARCHAR(255) NOT NULL,
    DiaChi VARCHAR(255) NOT NULL,
    DienThoai VARCHAR(20) NULL,
    Email VARCHAR(255) NULL,
    CongChungVien VARCHAR(255) NOT NULL,
    TenDanhDau VARCHAR(50) NULL,
    DiaChiDanhDau VARCHAR(50) NULL,
    CongChungVienDanhDau VARCHAR(50) NULL,
    DienGiai TEXT NULL,
    NguoiTao INT NOT NULL,
    NguoiCapNhat INT DEFAULT NULL,
    NgayTao DATETIME NOT NULL,
    NgayCapNhat DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

----------------------------------------------------------------
-- 10. BẢNG NGUOI_DUNG
----------------------------------------------------------------
CREATE TABLE NguoiDung (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    TenDangNhap VARCHAR(255) NOT NULL,
    MatKhau VARCHAR(255) NOT NULL,
    QuyenHan ENUM('QuanTri','NhanVien') NOT NULL,
    HoVaTen VARCHAR(255) NULL,
    Email VARCHAR(255) NULL,
    DienGiai TEXT NULL,
    NguoiTao INT NOT NULL,
    NguoiCapNhat INT DEFAULT NULL,
    NgayTao DATETIME NOT NULL,
    NgayCapNhat DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;