use hrss;
INSERT INTO `hrss`.`Departments`(`DepartmentCode`,`DepartmentName`,`Description`,`CreatedBy`,`CreatedAt`,`UpdatedBy`,`UpdatedAt`)
VALUES('DEFAULT','Default Department','',0,NOW(),null,null);
INSERT INTO `hrss`.`Positions`(`PositionCode`,`PositionName`,`Description`,`CreatedBy`,`CreatedAt`,`UpdatedBy`,`UpdatedAt`)
VALUES('DEFAULT','Default Position','',0,NOW(),null,null);

-- Employee 1: admin (full roles) - pw admin
INSERT INTO `hrss`.`Employees`
(`EmployeeCode`,`CardCode`,`LastName`,`FirstName`,`FullName`,`EnglishName`,`Image`,`Gender`,`DateOfBirth`,
`PlaceOfBirth`,`Nationality`,`Ethnicity`,`Religion`,`BloodType`,`MaritalStatus`,`Occupation`,`Address`,
`Address2`,`PhoneNumber`,`Email`,`CitizenID`,`CitizenIDIssuedDate`,`CitizenIDIssuedPlace`,
`PassportNumber`,`PassportIssuedDate`,`PassportIssuedPlace`,`PassportExpiredDate`,
`Height`,`Weight`,`NumberOfChildren`,`EducationLevel`,`SocialInsuranceNumber`,`SocialInsuranceIssuedDate`,
`SocialInsuranceIssuedPlace`,`HealthInsuranceNumber`,`HealthInsuranceIssuedDate`,`HealthInsuranceIssuedPlace`,
`HealthCareRegisterPlace`,`LaborBookNumber`,`LaborBookIssuedDate`,`LaborBookIssuedPlace`,
`TaxCode`,`DepartmentCode`,`PositionCode`,`BankName`,`BankAccountNumber`,`IsResigned`,`ResignedDate`,
`ResignedReason`,`HireDate`,`ProbationDays`,`ProbationEndDate`,`IsProbationEnded`,`ProbationResult`,
`IsUserLogin`,`Username`,`PasswordHash`,`UserRole`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES
('DEFAULT01',null,'Văn Thành', 'Lê', 'Lê Văn Thành',null,null,
'Male','1985-03-04','TPHCM','Việt Nam',null,null,null,'Single','Kỹ sư',
'B567 Nguyễn Trãi, phường 2, quận 6, TPHCM',null,null,'default01@test.com',
'2890038495049','2021-11-28','Cục Cảnh sát về TTXH',null,
'1980-01-01',null,'1980-01-01',0,0,2,null,null,'1980-01-01',null,null,'1980-01-01',null,null,
'12345','1980-01-01',null,null,'DEFAULT','DEFAULT',null,null,0,null,null,'2020-05-05',60,'2020-07-05',
1,null,1,'admin','$2a$12$C1MDc0Uz.n1acMsIVl1aOOuu.8aeT.AiPvcMBco0kcoBqn/7vFHh6',
'["Admin","HREmployee","HRManager","Payroll","Manager","HiringEmployee","HiringManager","Employee"]',
null,0,NOW());

INSERT INTO `hrss`.`ContractTypes`(`ContractTypeCode`,`ContractTypeName`,`Months`,`Years`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('1Y','Hợp đồng 1 năm',0,1,'',0,NOW());
INSERT INTO `hrss`.`ContractTypes`(`ContractTypeCode`,`ContractTypeName`,`Months`,`Years`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('2Y','Hợp đồng 2 năm',0,2,'',0,NOW());
INSERT INTO `hrss`.`ContractTypes`(`ContractTypeCode`,`ContractTypeName`,`Months`,`Years`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('0Y','Hợp đồng không thời hạn',0,0,'',0,NOW());
INSERT INTO `hrss`.`ContractTypes`(`ContractTypeCode`,`ContractTypeName`,`Months`,`Years`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('Probation','Hợp đồng thử việc',2,0,'',0,NOW());

INSERT INTO `hrss`.`DefaultContractSettings`
(`WorkingTime`,`WorkingDays`,`PerformanceAllowance`,`OtherAllowances`,`EffectiveSalary`,`TravelAllowance`,`SalaryPaymentMethod`,`WeeklyLeaveSchedule`,
`OtherBenefits`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('Toàn thời gian','Từ ngày thứ 2 đến sáng ngày thứ 7:
 - Buổi sáng: 8h00 – 12h00
 - Buổi chiều: 13h30 – 17h30
 - Sáng ngày thứ 7: Làm việc từ 08h00 đến 12h00','Theo đánh giá của quản lý',null,'Theo quy định của phòng ban, công ty',
 'Tùy từng vị trí, người lao động được hưởng theo quy định của công ty','Chuyển khoản','1,5 ngày (Chiều Thứ 7 và ngày Chủ nhật)',
<null,null,0,NOW());

INSERT INTO `hrss`.`PayrollSettings`
(`WorkingHoursMonday`,`WorkingHoursTuesday`,`WorkingHoursWednesday`,`WorkingHoursThursday`,`WorkingHoursFriday`,`WorkingHoursSaturday`,`WorkingHoursSunday`,
`PersonalDeduction`,`DependentDeduction`,`SocialInsurancePercent`,`HealthInsurancePercent`,`UnemploymentInsurancePercent`,`Description`,
`CreatedBy`,`CreatedAt`,`MaximumInsuranceDeduction`)
VALUES(8,8,8,8,8,0,0,11000000,4400000,8,1.5,1,null,1,NOW(),46800000);

INSERT INTO `hrss`.`TaxBrackets`(`IncomeLevel`,`TaxPercent`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES(5000000,5,'Thu nhập chịu thuế từ 0-5tr đóng thuế 5%',0,NOW());
INSERT INTO `hrss`.`TaxBrackets`(`IncomeLevel`,`TaxPercent`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES(10000000,10,'Thu nhập chịu thuế từ > 5tr đến 10tr đóng thuế 10%',0,NOW());
INSERT INTO `hrss`.`TaxBrackets`(`IncomeLevel`,`TaxPercent`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES(18000000,15,'Thu nhập chịu thuế từ > 10tr đến 18tr đóng thuế 15%',0,NOW());
INSERT INTO `hrss`.`TaxBrackets`(`IncomeLevel`,`TaxPercent`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES(32000000,20,'Thu nhập chịu thuế từ > 18tr đến 32tr đóng thuế 20%',0,NOW());
INSERT INTO `hrss`.`TaxBrackets`(`IncomeLevel`,`TaxPercent`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES(52000000,25,'Thu nhập chịu thuế từ > 32tr đến 52tr đóng thuế 25%',0,NOW());
INSERT INTO `hrss`.`TaxBrackets`(`IncomeLevel`,`TaxPercent`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES(80000000,30,'Thu nhập chịu thuế từ > 52tr đến 80tr đóng thuế 30%',0,NOW());
INSERT INTO `hrss`.`TaxBrackets`(`IncomeLevel`,`TaxPercent`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES(100000000000,35,'Thu nhập chịu thuế hơn 80 triệu (nhập 100 tỷ làm số tượng trưng) đóng thuế 35%',0,NOW());

INSERT INTO `hrss`.`LeaveTypes`(`LeaveCode`,`LeaveName`,`IsPaid`,`IsSocialInsurance`,`AllowedDaysPerYear`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('AL','Phép năm',1,0,12,null,0,NOW());
INSERT INTO `hrss`.`LeaveTypes`(`LeaveCode`,`LeaveName`,`IsPaid`,`IsSocialInsurance`,`AllowedDaysPerYear`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('SL','Nghỉ bệnh',0,1,5,null,0,NOW());
INSERT INTO `hrss`.`LeaveTypes`(`LeaveCode`,`LeaveName`,`IsPaid`,`IsSocialInsurance`,`AllowedDaysPerYear`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('KSL','Nghỉ con ốm',0,1,5,null,0,NOW());
INSERT INTO `hrss`.`LeaveTypes`(`LeaveCode`,`LeaveName`,`IsPaid`,`IsSocialInsurance`,`AllowedDaysPerYear`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('NS','Nghỉ không lương',0,0,5,null,0,NOW());

INSERT INTO `hrss`.`Companies`
(`CompanyNo`,`CompanyName`,`TaxCode`,`BankAccountNumber`,`BankName`,`Address`,
`PhoneNumber`,`RepresentativeName`,`RepresentativePosition`,`RepresentativeGender`,
`RepresentativeNationality`,`RepresentativeTaxCode`,`RepresentativeBankAccount`,
`RepresentativeBankName`,`RepresentativePhone`,`RepresentativeEmail`,`Description`,
`CreatedBy`,`CreatedAt`)
VALUES
('00001','Công ty TNHH Đại Hưng','09765434332345433','1234567891002024',
'Ngân hàng thương mại XNK Eximbank','B675 Nguyễn Văn Tâm, Phường 2, Quận 10, TPHCM',
'0987977543','Trần Văn Tâm','Giám đốc nhân sự','Male','Việt Nam','45443456545343',
'98098493048381300','Ngân hàng thương mại XNK Eximbank','0899766578','tamtr@daihung.vn',null,
0,NOW());

INSERT INTO `hrss`.`OvertimeTypes`(`OvertimeCode`,`OvertimeName`,`OvertimeRate`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('WK','Tăng ca cuối tuần',2,null,0,NOW());
INSERT INTO `hrss`.`OvertimeTypes`(`OvertimeCode`,`OvertimeName`,`OvertimeRate`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('Holiday','Tăng ca ngày lễ',3,null,0,NOW());
INSERT INTO `hrss`.`OvertimeTypes`(`OvertimeCode`,`OvertimeName`,`OvertimeRate`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('Night','Tăng ca buổi tối',1.5,null,0,NOW());