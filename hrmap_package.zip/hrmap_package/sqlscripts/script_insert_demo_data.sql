use hrss;
INSERT INTO `hrss`.`Departments`(`DepartmentCode`,`DepartmentName`,`Description`,`CreatedBy`,`CreatedAt`,`UpdatedBy`,`UpdatedAt`)
VALUES('DEFAULT','Default Department','',0,NOW(),null,null);
INSERT INTO `hrss`.`Positions`(`PositionCode`,`PositionName`,`Description`,`CreatedBy`,`CreatedAt`,`UpdatedBy`,`UpdatedAt`)
VALUES('DEFAULT','Default Position','',0,NOW(),null,null);

-- Employee 1: admin (full roles) - pw admin
INSERT INTO `hrss`.`Employees`
(`EmployeeCode`,`CardCode`,`LastName`,`FirstName`,`FullName`,`EnglishName`,`Image`,`Gender`,`DateOfBirth`,
`PlaceOfBirth`,`Nationality`,`Ethnicity`,`Religion`,`BloodType`,`MaritalStatus`,`Occupation`,`Address`,
`Address2`,`PhoneNumber`,`Email`,`CitizenID`,`CitizenIDIssuedDate`,`CitizenIDIssuedPlace`,
`PassportNumber`,`PassportIssuedDate`,`PassportIssuedPlace`,`PassportExpiredDate`,
`Height`,`Weight`,`NumberOfChildren`,`EducationLevel`,`SocialInsuranceNumber`,`SocialInsuranceIssuedDate`,
`SocialInsuranceIssuedPlace`,`HealthInsuranceNumber`,`HealthInsuranceIssuedDate`,`HealthInsuranceIssuedPlace`,
`HealthCareRegisterPlace`,`LaborBookNumber`,`LaborBookIssuedDate`,`LaborBookIssuedPlace`,
`TaxCode`,`DepartmentCode`,`PositionCode`,`BankName`,`BankAccountNumber`,`IsResigned`,`ResignedDate`,
`ResignedReason`,`HireDate`,`ProbationDays`,`ProbationEndDate`,`IsProbationEnded`,`ProbationResult`,
`IsUserLogin`,`Username`,`PasswordHash`,`UserRole`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES
('DEFAULT01',null,'Văn Thành', 'Lê', 'Lê Văn Thành',null,null,
'Male','1985-03-04','TPHCM','Việt Nam',null,null,null,'Single','Kỹ sư',
'B567 Nguyễn Trãi, phường 2, quận 6, TPHCM',null,null,'default01@test.com',
'2890038495049','2021-11-28','Cục Cảnh sát về TTXH',null,
'1980-01-01',null,'1980-01-01',0,0,2,null,null,'1980-01-01',null,null,'1980-01-01',null,null,
'12345','1980-01-01',null,null,'DEFAULT','DEFAULT',null,null,0,null,null,'2020-05-05',60,'2020-07-05',
1,null,1,'admin','$2a$12$C1MDc0Uz.n1acMsIVl1aOOuu.8aeT.AiPvcMBco0kcoBqn/7vFHh6',
'["Admin","HREmployee","HRManager","Payroll","Manager","HiringEmployee","HiringManager","Employee"]',
null,0,NOW());

-- Employee 2: hremp (HREmployee), pw 123
INSERT INTO `hrss`.`Employees`
(`EmployeeCode`,`CardCode`,`LastName`,`FirstName`,`FullName`,`EnglishName`,`Image`,`Gender`,`DateOfBirth`,
`PlaceOfBirth`,`Nationality`,`Ethnicity`,`Religion`,`BloodType`,`MaritalStatus`,`Occupation`,`Address`,
`Address2`,`PhoneNumber`,`Email`,`CitizenID`,`CitizenIDIssuedDate`,`CitizenIDIssuedPlace`,
`PassportNumber`,`PassportIssuedDate`,`PassportIssuedPlace`,`PassportExpiredDate`,
`Height`,`Weight`,`NumberOfChildren`,`EducationLevel`,`SocialInsuranceNumber`,`SocialInsuranceIssuedDate`,
`SocialInsuranceIssuedPlace`,`HealthInsuranceNumber`,`HealthInsuranceIssuedDate`,`HealthInsuranceIssuedPlace`,
`HealthCareRegisterPlace`,`LaborBookNumber`,`LaborBookIssuedDate`,`LaborBookIssuedPlace`,
`TaxCode`,`DepartmentCode`,`PositionCode`,`BankName`,`BankAccountNumber`,`IsResigned`,`ResignedDate`,
`ResignedReason`,`HireDate`,`ProbationDays`,`ProbationEndDate`,`IsProbationEnded`,`ProbationResult`,
`IsUserLogin`,`Username`,`PasswordHash`,`UserRole`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES
('DEFAULT02',null,'Văn Tài', 'Trần', 'Trần Văn Tài',null,null,
'Male','1985-03-04','TPHCM','Việt Nam',null,null,null,'Single','Kế toán',
'57 Nguyễn Trãi, phường 3, quận 6, TPHCM',null,null,'default02@test.com',
'28934638495049','2021-11-28','Cục Cảnh sát về TTXH',null,
'1980-01-01',null,'1980-01-01',0,0,2,null,null,'1980-01-01',null,null,'1980-01-01',null,null,
'34353','1980-01-01',null,null,'DEFAULT','DEFAULT',null,null,0,null,null,'2020-05-05',60,'2020-07-05',
1,null,1,'hremp','$2b$10$PPwCyqncuMxeQY.OyZ3rGOvf0nWaNzy5iXN7d5p.Yx9uHE2Pj.pNm',
'["HREmployee","Employee"]',null,0,NOW());

-- Employee 3: payroll, pw 123
INSERT INTO `hrss`.`Employees`
(`EmployeeCode`,`CardCode`,`LastName`,`FirstName`,`FullName`,`EnglishName`,`Image`,`Gender`,`DateOfBirth`,
`PlaceOfBirth`,`Nationality`,`Ethnicity`,`Religion`,`BloodType`,`MaritalStatus`,`Occupation`,`Address`,
`Address2`,`PhoneNumber`,`Email`,`CitizenID`,`CitizenIDIssuedDate`,`CitizenIDIssuedPlace`,
`PassportNumber`,`PassportIssuedDate`,`PassportIssuedPlace`,`PassportExpiredDate`,
`Height`,`Weight`,`NumberOfChildren`,`EducationLevel`,`SocialInsuranceNumber`,`SocialInsuranceIssuedDate`,
`SocialInsuranceIssuedPlace`,`HealthInsuranceNumber`,`HealthInsuranceIssuedDate`,`HealthInsuranceIssuedPlace`,
`HealthCareRegisterPlace`,`LaborBookNumber`,`LaborBookIssuedDate`,`LaborBookIssuedPlace`,
`TaxCode`,`DepartmentCode`,`PositionCode`,`BankName`,`BankAccountNumber`,`IsResigned`,`ResignedDate`,
`ResignedReason`,`HireDate`,`ProbationDays`,`ProbationEndDate`,`IsProbationEnded`,`ProbationResult`,
`IsUserLogin`,`Username`,`PasswordHash`,`UserRole`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES
('DEFAULT03',null,'Thanh Quang', 'Dương', 'Dương Thanh Quang',null,null,
'Male','1985-03-04','TPHCM','Việt Nam',null,null,null,'Single','Nhân viên IT',
'57 Nguyễn Trãi, phường 5, quận 6, TPHCM',null,null,'default03@test.com',
'28930000049','2021-11-28','Cục Cảnh sát về TTXH',null,
'1980-01-01',null,'1980-01-01',0,0,2,null,null,'1980-01-01',null,null,'1980-01-01',null,null,
'000003','1980-01-01',null,null,'DEFAULT','DEFAULT',null,null,0,null,null,'2020-05-05',60,'2020-07-05',
1,null,1,'payroll','$2b$10$PPwCyqncuMxeQY.OyZ3rGOvf0nWaNzy5iXN7d5p.Yx9uHE2Pj.pNm',
'["Payroll","Employee"]',null,0,NOW());

-- Employee 4: manager, pw 123
INSERT INTO `hrss`.`Employees`
(`EmployeeCode`,`CardCode`,`LastName`,`FirstName`,`FullName`,`EnglishName`,`Image`,`Gender`,`DateOfBirth`,
`PlaceOfBirth`,`Nationality`,`Ethnicity`,`Religion`,`BloodType`,`MaritalStatus`,`Occupation`,`Address`,
`Address2`,`PhoneNumber`,`Email`,`CitizenID`,`CitizenIDIssuedDate`,`CitizenIDIssuedPlace`,
`PassportNumber`,`PassportIssuedDate`,`PassportIssuedPlace`,`PassportExpiredDate`,
`Height`,`Weight`,`NumberOfChildren`,`EducationLevel`,`SocialInsuranceNumber`,`SocialInsuranceIssuedDate`,
`SocialInsuranceIssuedPlace`,`HealthInsuranceNumber`,`HealthInsuranceIssuedDate`,`HealthInsuranceIssuedPlace`,
`HealthCareRegisterPlace`,`LaborBookNumber`,`LaborBookIssuedDate`,`LaborBookIssuedPlace`,
`TaxCode`,`DepartmentCode`,`PositionCode`,`BankName`,`BankAccountNumber`,`IsResigned`,`ResignedDate`,
`ResignedReason`,`HireDate`,`ProbationDays`,`ProbationEndDate`,`IsProbationEnded`,`ProbationResult`,
`IsUserLogin`,`Username`,`PasswordHash`,`UserRole`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES
('DEFAULT04',null,'Thành Tài', 'Nguyễn', 'Nguyễn Thành Tài',null,null,
'Male','1985-03-04','TPHCM','Việt Nam',null,null,null,'Single','Nhân viên sale',
'44 Nguyễn Trãi, phường 5, quận 6, TPHCM',null,null,'default04@test.com',
'280202020049','2021-11-28','Cục Cảnh sát về TTXH',null,
'1980-01-01',null,'1980-01-01',0,0,0,null,null,'1980-01-01',null,null,'1980-01-01',null,null,
'000004','1980-01-01',null,null,'DEFAULT','DEFAULT',null,null,0,null,null,'2020-05-05',60,'2020-07-05',
1,null,1,'manager','$2b$10$PPwCyqncuMxeQY.OyZ3rGOvf0nWaNzy5iXN7d5p.Yx9uHE2Pj.pNm',
'["Manager","Employee"]',null,0,NOW());

-- Employee 5: hrmanager, pw 123
INSERT INTO `hrss`.`Employees`
(`EmployeeCode`,`CardCode`,`LastName`,`FirstName`,`FullName`,`EnglishName`,`Image`,`Gender`,`DateOfBirth`,
`PlaceOfBirth`,`Nationality`,`Ethnicity`,`Religion`,`BloodType`,`MaritalStatus`,`Occupation`,`Address`,
`Address2`,`PhoneNumber`,`Email`,`CitizenID`,`CitizenIDIssuedDate`,`CitizenIDIssuedPlace`,
`PassportNumber`,`PassportIssuedDate`,`PassportIssuedPlace`,`PassportExpiredDate`,
`Height`,`Weight`,`NumberOfChildren`,`EducationLevel`,`SocialInsuranceNumber`,`SocialInsuranceIssuedDate`,
`SocialInsuranceIssuedPlace`,`HealthInsuranceNumber`,`HealthInsuranceIssuedDate`,`HealthInsuranceIssuedPlace`,
`HealthCareRegisterPlace`,`LaborBookNumber`,`LaborBookIssuedDate`,`LaborBookIssuedPlace`,
`TaxCode`,`DepartmentCode`,`PositionCode`,`BankName`,`BankAccountNumber`,`IsResigned`,`ResignedDate`,
`ResignedReason`,`HireDate`,`ProbationDays`,`ProbationEndDate`,`IsProbationEnded`,`ProbationResult`,
`IsUserLogin`,`Username`,`PasswordHash`,`UserRole`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES
('DEFAULT05',null,'Văn Thông', 'Trương', 'Trương Văn Thông',null,null,
'Male','1988-03-04','TPHCM','Việt Nam',null,null,null,'Single','Nhân viên kho',
'44 Nguyễn Thái Bình, phường 5, quận 6, TPHCM',null,null,'default05@test.com',
'28305050520049','2021-11-28','Cục Cảnh sát về TTXH',null,
'1980-01-01',null,'1980-01-01',0,0,1,null,null,'1980-01-01',null,null,'1980-01-01',null,null,
'000005','1980-01-01',null,null,'DEFAULT','DEFAULT',null,null,0,null,null,'2020-05-05',60,'2020-07-05',
1,null,1,'hrmanager','$2b$10$PPwCyqncuMxeQY.OyZ3rGOvf0nWaNzy5iXN7d5p.Yx9uHE2Pj.pNm',
'["HRManager","Employee"]',null,0,NOW());

-- Employee 6: employee, pw 123
INSERT INTO `hrss`.`Employees`
(`EmployeeCode`,`CardCode`,`LastName`,`FirstName`,`FullName`,`EnglishName`,`Image`,`Gender`,`DateOfBirth`,
`PlaceOfBirth`,`Nationality`,`Ethnicity`,`Religion`,`BloodType`,`MaritalStatus`,`Occupation`,`Address`,
`Address2`,`PhoneNumber`,`Email`,`CitizenID`,`CitizenIDIssuedDate`,`CitizenIDIssuedPlace`,
`PassportNumber`,`PassportIssuedDate`,`PassportIssuedPlace`,`PassportExpiredDate`,
`Height`,`Weight`,`NumberOfChildren`,`EducationLevel`,`SocialInsuranceNumber`,`SocialInsuranceIssuedDate`,
`SocialInsuranceIssuedPlace`,`HealthInsuranceNumber`,`HealthInsuranceIssuedDate`,`HealthInsuranceIssuedPlace`,
`HealthCareRegisterPlace`,`LaborBookNumber`,`LaborBookIssuedDate`,`LaborBookIssuedPlace`,
`TaxCode`,`DepartmentCode`,`PositionCode`,`BankName`,`BankAccountNumber`,`IsResigned`,`ResignedDate`,
`ResignedReason`,`HireDate`,`ProbationDays`,`ProbationEndDate`,`IsProbationEnded`,`ProbationResult`,
`IsUserLogin`,`Username`,`PasswordHash`,`UserRole`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES
('DEFAULT06',null,'Tấn Hoàng', 'Lê', 'Lê Tấn Hoàng',null,null,
'Male','1994-03-04','TPHCM','Việt Nam',null,null,null,'Single','Thư ký',
'06 Nguyễn Thái Bình, phường 5, quận 6, TPHCM',null,null,'default06@test.com',
'28060606060049','2021-11-28','Cục Cảnh sát về TTXH',null,
'1980-01-01',null,'1980-01-01',0,0,3,null,null,'1980-01-01',null,null,'1980-01-01',null,null,
'000006','1980-01-01',null,null,'DEFAULT','DEFAULT',null,null,0,null,null,'2020-05-05',60,'2020-07-05',
1,null,1,'employee','$2b$10$PPwCyqncuMxeQY.OyZ3rGOvf0nWaNzy5iXN7d5p.Yx9uHE2Pj.pNm',
'["Employee"]',null,0,NOW());

-- Employee 7: no login
INSERT INTO `hrss`.`Employees`
(`EmployeeCode`,`CardCode`,`LastName`,`FirstName`,`FullName`,`EnglishName`,`Image`,`Gender`,`DateOfBirth`,
`PlaceOfBirth`,`Nationality`,`Ethnicity`,`Religion`,`BloodType`,`MaritalStatus`,`Occupation`,`Address`,
`Address2`,`PhoneNumber`,`Email`,`CitizenID`,`CitizenIDIssuedDate`,`CitizenIDIssuedPlace`,
`PassportNumber`,`PassportIssuedDate`,`PassportIssuedPlace`,`PassportExpiredDate`,
`Height`,`Weight`,`NumberOfChildren`,`EducationLevel`,`SocialInsuranceNumber`,`SocialInsuranceIssuedDate`,
`SocialInsuranceIssuedPlace`,`HealthInsuranceNumber`,`HealthInsuranceIssuedDate`,`HealthInsuranceIssuedPlace`,
`HealthCareRegisterPlace`,`LaborBookNumber`,`LaborBookIssuedDate`,`LaborBookIssuedPlace`,
`TaxCode`,`DepartmentCode`,`PositionCode`,`BankName`,`BankAccountNumber`,`IsResigned`,`ResignedDate`,
`ResignedReason`,`HireDate`,`ProbationDays`,`ProbationEndDate`,`IsProbationEnded`,`ProbationResult`,
`IsUserLogin`,`Username`,`PasswordHash`,`UserRole`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES
('DEFAULT07',null,'Hồng Hà', 'Nguyễn', 'Nguyễn Hồng Hà',null,null,
'Male','1994-03-04','TPHCM','Việt Nam',null,null,null,'Single','Kinh doanh',
'07 Nguyễn Thái Bình, phường 5, quận 6, TPHCM',null,null,'default07@test.com',
'2806007070749','2021-11-28','Cục Cảnh sát về TTXH',null,
'1980-01-01',null,'1980-01-01',0,0,3,null,null,'1980-01-01',null,null,'1980-01-01',null,null,
'000007','1980-01-01',null,null,'DEFAULT','DEFAULT',null,null,0,null,null,'2020-05-05',60,'2020-07-05',
1,null,0,null,null,null,null,0,NOW());

-- Employee 8: no login
INSERT INTO `hrss`.`Employees`
(`EmployeeCode`,`CardCode`,`LastName`,`FirstName`,`FullName`,`EnglishName`,`Image`,`Gender`,`DateOfBirth`,
`PlaceOfBirth`,`Nationality`,`Ethnicity`,`Religion`,`BloodType`,`MaritalStatus`,`Occupation`,`Address`,
`Address2`,`PhoneNumber`,`Email`,`CitizenID`,`CitizenIDIssuedDate`,`CitizenIDIssuedPlace`,
`PassportNumber`,`PassportIssuedDate`,`PassportIssuedPlace`,`PassportExpiredDate`,
`Height`,`Weight`,`NumberOfChildren`,`EducationLevel`,`SocialInsuranceNumber`,`SocialInsuranceIssuedDate`,
`SocialInsuranceIssuedPlace`,`HealthInsuranceNumber`,`HealthInsuranceIssuedDate`,`HealthInsuranceIssuedPlace`,
`HealthCareRegisterPlace`,`LaborBookNumber`,`LaborBookIssuedDate`,`LaborBookIssuedPlace`,
`TaxCode`,`DepartmentCode`,`PositionCode`,`BankName`,`BankAccountNumber`,`IsResigned`,`ResignedDate`,
`ResignedReason`,`HireDate`,`ProbationDays`,`ProbationEndDate`,`IsProbationEnded`,`ProbationResult`,
`IsUserLogin`,`Username`,`PasswordHash`,`UserRole`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES
('DEFAULT08',null,'Hoàng Bảo', 'Nguyễn', 'Nguyễn Hoàng Bảo',null,null,
'Male','1995-03-04','TPHCM','Việt Nam',null,null,null,'Single','Kinh doanh',
'08 Nguyễn Thái Bình, phường 5, quận 6, TPHCM',null,null,'default08@test.com',
'28008080870749','2021-11-28','Cục Cảnh sát về TTXH',null,
'1980-01-01',null,'1980-01-01',0,0,3,null,null,'1980-01-01',null,null,'1980-01-01',null,null,
'000008','1980-01-01',null,null,'DEFAULT','DEFAULT',null,null,0,null,null,'2020-05-05',60,'2020-07-05',
1,null,0,null,null,null,null,0,NOW());

-- Employee 9: no login
INSERT INTO `hrss`.`Employees`
(`EmployeeCode`,`CardCode`,`LastName`,`FirstName`,`FullName`,`EnglishName`,`Image`,`Gender`,`DateOfBirth`,
`PlaceOfBirth`,`Nationality`,`Ethnicity`,`Religion`,`BloodType`,`MaritalStatus`,`Occupation`,`Address`,
`Address2`,`PhoneNumber`,`Email`,`CitizenID`,`CitizenIDIssuedDate`,`CitizenIDIssuedPlace`,
`PassportNumber`,`PassportIssuedDate`,`PassportIssuedPlace`,`PassportExpiredDate`,
`Height`,`Weight`,`NumberOfChildren`,`EducationLevel`,`SocialInsuranceNumber`,`SocialInsuranceIssuedDate`,
`SocialInsuranceIssuedPlace`,`HealthInsuranceNumber`,`HealthInsuranceIssuedDate`,`HealthInsuranceIssuedPlace`,
`HealthCareRegisterPlace`,`LaborBookNumber`,`LaborBookIssuedDate`,`LaborBookIssuedPlace`,
`TaxCode`,`DepartmentCode`,`PositionCode`,`BankName`,`BankAccountNumber`,`IsResigned`,`ResignedDate`,
`ResignedReason`,`HireDate`,`ProbationDays`,`ProbationEndDate`,`IsProbationEnded`,`ProbationResult`,
`IsUserLogin`,`Username`,`PasswordHash`,`UserRole`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES
('DEFAULT09',null,'Gia Bảo', 'Lê', 'Lê Gia Bảo',null,null,
'Male','2000-03-04','TPHCM','Việt Nam',null,null,null,'Single','Kinh doanh',
'09 Nguyễn Thái Bình, phường 5, quận 6, TPHCM',null,null,'default09@test.com',
'280090990749','2021-11-28','Cục Cảnh sát về TTXH',null,
'1980-01-01',null,'1980-01-01',0,0,3,null,null,'1980-01-01',null,null,'1980-01-01',null,null,
'000009','1980-01-01',null,null,'DEFAULT','DEFAULT',null,null,0,null,null,'2020-05-05',60,'2020-07-05',
1,null,0,null,null,null,null,0,NOW());

-- Employee 10: no login
INSERT INTO `hrss`.`Employees`
(`EmployeeCode`,`CardCode`,`LastName`,`FirstName`,`FullName`,`EnglishName`,`Image`,`Gender`,`DateOfBirth`,
`PlaceOfBirth`,`Nationality`,`Ethnicity`,`Religion`,`BloodType`,`MaritalStatus`,`Occupation`,`Address`,
`Address2`,`PhoneNumber`,`Email`,`CitizenID`,`CitizenIDIssuedDate`,`CitizenIDIssuedPlace`,
`PassportNumber`,`PassportIssuedDate`,`PassportIssuedPlace`,`PassportExpiredDate`,
`Height`,`Weight`,`NumberOfChildren`,`EducationLevel`,`SocialInsuranceNumber`,`SocialInsuranceIssuedDate`,
`SocialInsuranceIssuedPlace`,`HealthInsuranceNumber`,`HealthInsuranceIssuedDate`,`HealthInsuranceIssuedPlace`,
`HealthCareRegisterPlace`,`LaborBookNumber`,`LaborBookIssuedDate`,`LaborBookIssuedPlace`,
`TaxCode`,`DepartmentCode`,`PositionCode`,`BankName`,`BankAccountNumber`,`IsResigned`,`ResignedDate`,
`ResignedReason`,`HireDate`,`ProbationDays`,`ProbationEndDate`,`IsProbationEnded`,`ProbationResult`,
`IsUserLogin`,`Username`,`PasswordHash`,`UserRole`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES
('DEFAULT10',null,'Việt Anh', 'Lê', 'Lê Việt Anh',null,null,
'Male','2001-03-04','TPHCM','Việt Nam',null,null,null,'Single','Kinh doanh',
'10 Nguyễn Thái Bình, phường 5, quận 6, TPHCM',null,null,'default10@test.com',
'21010101010749','2021-11-28','Cục Cảnh sát về TTXH',null,
'1980-01-01',null,'1980-01-01',0,0,1,null,null,'1980-01-01',null,null,'1980-01-01',null,null,
'000010','1980-01-01',null,null,'DEFAULT','DEFAULT',null,null,0,null,null,'2020-05-05',60,'2020-07-05',
1,null,0,null,null,null,null,0,NOW());

INSERT INTO `hrss`.`ContractTypes`(`ContractTypeCode`,`ContractTypeName`,`Months`,`Years`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('1Y','Hợp đồng 1 năm',0,1,'',0,NOW());
INSERT INTO `hrss`.`ContractTypes`(`ContractTypeCode`,`ContractTypeName`,`Months`,`Years`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('2Y','Hợp đồng 2 năm',0,2,'',0,NOW());
INSERT INTO `hrss`.`ContractTypes`(`ContractTypeCode`,`ContractTypeName`,`Months`,`Years`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('0Y','Hợp đồng không thời hạn',0,0,'',0,NOW());
INSERT INTO `hrss`.`ContractTypes`(`ContractTypeCode`,`ContractTypeName`,`Months`,`Years`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('Probation','Hợp đồng thử việc',2,0,'',0,NOW());

INSERT INTO `hrss`.`DefaultContractSettings`
(`WorkingTime`,`WorkingDays`,`PerformanceAllowance`,`OtherAllowances`,`EffectiveSalary`,`TravelAllowance`,`SalaryPaymentMethod`,`WeeklyLeaveSchedule`,
`OtherBenefits`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('Toàn thời gian','Từ ngày thứ 2 đến sáng ngày thứ 7:
 - Buổi sáng: 8h00 – 12h00
 - Buổi chiều: 13h30 – 17h30
 - Sáng ngày thứ 7: Làm việc từ 08h00 đến 12h00','Theo đánh giá của quản lý',null,'Theo quy định của phòng ban, công ty',
 'Tùy từng vị trí, người lao động được hưởng theo quy định của công ty','Chuyển khoản','1,5 ngày (Chiều Thứ 7 và ngày Chủ nhật)',
null,null,0,NOW());

INSERT INTO `hrss`.`PayrollSettings`
(`WorkingHoursMonday`,`WorkingHoursTuesday`,`WorkingHoursWednesday`,`WorkingHoursThursday`,`WorkingHoursFriday`,`WorkingHoursSaturday`,`WorkingHoursSunday`,
`PersonalDeduction`,`DependentDeduction`,`SocialInsurancePercent`,`HealthInsurancePercent`,`UnemploymentInsurancePercent`,`Description`,
`CreatedBy`,`CreatedAt`,`MaximumInsuranceDeduction`)
VALUES(8,8,8,8,8,0,0,11000000,4400000,8,1.5,1,null,1,NOW(),46800000);

INSERT INTO `hrss`.`TaxBrackets`(`IncomeLevel`,`TaxPercent`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES(5000000,5,'Thu nhập chịu thuế từ 0-5tr đóng thuế 5%',0,NOW());
INSERT INTO `hrss`.`TaxBrackets`(`IncomeLevel`,`TaxPercent`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES(10000000,10,'Thu nhập chịu thuế từ > 5tr đến 10tr đóng thuế 10%',0,NOW());
INSERT INTO `hrss`.`TaxBrackets`(`IncomeLevel`,`TaxPercent`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES(18000000,15,'Thu nhập chịu thuế từ > 10tr đến 18tr đóng thuế 15%',0,NOW());
INSERT INTO `hrss`.`TaxBrackets`(`IncomeLevel`,`TaxPercent`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES(32000000,20,'Thu nhập chịu thuế từ > 18tr đến 32tr đóng thuế 20%',0,NOW());
INSERT INTO `hrss`.`TaxBrackets`(`IncomeLevel`,`TaxPercent`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES(52000000,25,'Thu nhập chịu thuế từ > 32tr đến 52tr đóng thuế 25%',0,NOW());
INSERT INTO `hrss`.`TaxBrackets`(`IncomeLevel`,`TaxPercent`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES(80000000,30,'Thu nhập chịu thuế từ > 52tr đến 80tr đóng thuế 30%',0,NOW());
INSERT INTO `hrss`.`TaxBrackets`(`IncomeLevel`,`TaxPercent`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES(100000000000,35,'Thu nhập chịu thuế hơn 80 triệu (nhập 100 tỷ làm số tượng trưng) đóng thuế 35%',0,NOW());

INSERT INTO `hrss`.`Contracts`
(`ContractNo`,`EmployeeCode`,`DepartmentCode`,`PositionCode`,`ContractTypeCode`,`ContractDate`,`StartDate`,`EndDate`,
`JobDescription`,`WorkingTime`,`WorkingDays`,`AdditionalDuties`,`ResponsibilityAllowance`,`PerformanceAllowance`,
`OtherAllowances`,`EffectiveSalary`,`GrossSalary`,`TravelAllowance`,`SalaryPaymentMethod`,`SalaryPaymentTime`,`WeeklyLeaveSchedule`,
`OtherBenefits`,`ContractLocation`,`WorkLocation`,`WorkingTools`,`Transportation`,`BonusPolicy`,
`SalaryIncreasePolicy`,`LaborProtection`,`TrainingPolicy`,`SocialInsurance`,`HealthInsurance`,
`SignDate`,`EffectiveDate`,`IsSigned`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES
('00001','DEFAULT01','DEFAULT','DEFAULT','0Y','2025-01-01',
'2025-01-01','2075-01-01','- Thực hiện công việc theo đúng chức danh chuyên môn của mình dưới sự quản lý, điều hành của Ban Giám đốc (và các cá nhân được bổ nhiệm hoặc ủy quyền phụ trách).
 - Phối hợp cùng với các bộ phận, phòng ban khác trong Công ty để phát huy tối đa hiệu quả công việc.
 - Hoàn thành những công việc khác tùy thuộc theo yêu cầu kinh doanh của Công ty và theo quyết định của Ban Giám đốc (và các cá nhân được bổ nhiệm hoặc ủy quyền phụ trách).',
 'Toàn thời gian','Từ ngày thứ 2 đến sáng ngày thứ 7:
 - Buổi sáng: 8h00 – 12h00
 - Buổi chiều: 13h30 – 17h30
 - Sáng ngày thứ 7: Làm việc từ 08h00 đến 12h00', null,5000000,'Theo đánh giá của quản lý',null,'Theo quy định của phòng ban, công ty',49000000,
'Tùy từng vị trí, người lao động được hưởng theo quy định của công ty','Chuyển khoản','Được trả lương vào ngày cuối tháng','1,5 ngày (Chiều Thứ 7 và ngày Chủ nhật)',
null,'Số 15 Nguyễn Kiệm, phường 2, quận GV TPHCM','Số 15 Nguyễn Kiệm, phường 2, quận GV TPHCM',
'Thiết bị và công cụ làm việc sẽ được Công ty cấp phát tùy theo nhu cầu của công việc',null,null,
'Thực hiện theo Nghị định của Chính phủ quy định mức lương tối thiểu theo vùng, theo khu vực',
'Điều kiện an toàn và vệ sinh lao động tại nơi làm việc theo quy định của pháp luật hiện hành',
'Theo quy định của Công ty và yêu cầu công việc. Trong trường hợp CBNV được cử đi đào tạo thì nhân viên phải hoàn thành khoá học đúng thời hạn, phải cam kết sẽ phục vụ lâu dài cho Công ty sau khi kết thúc khoá học và được hưởng nguyên lương, các quyền lợi khác được  hưởng như người đi làm',
null,null,'2025-01-01','2025-01-01',1,null,0,NOW());

INSERT INTO `hrss`.`Contracts`
(`ContractNo`,`EmployeeCode`,`DepartmentCode`,`PositionCode`,`ContractTypeCode`,`ContractDate`,`StartDate`,`EndDate`,
`JobDescription`,`WorkingTime`,`WorkingDays`,`AdditionalDuties`,`ResponsibilityAllowance`,`PerformanceAllowance`,
`OtherAllowances`,`EffectiveSalary`,`GrossSalary`,`TravelAllowance`,`SalaryPaymentMethod`,`SalaryPaymentTime`,`WeeklyLeaveSchedule`,
`OtherBenefits`,`ContractLocation`,`WorkLocation`,`WorkingTools`,`Transportation`,`BonusPolicy`,
`SalaryIncreasePolicy`,`LaborProtection`,`TrainingPolicy`,`SocialInsurance`,`HealthInsurance`,
`SignDate`,`EffectiveDate`,`IsSigned`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES
('00002','DEFAULT02','DEFAULT','DEFAULT','0Y','2025-01-01',
'2025-01-01','2075-01-01','- Thực hiện công việc theo đúng chức danh chuyên môn của mình dưới sự quản lý, điều hành của Ban Giám đốc (và các cá nhân được bổ nhiệm hoặc ủy quyền phụ trách).
 - Phối hợp cùng với các bộ phận, phòng ban khác trong Công ty để phát huy tối đa hiệu quả công việc.
 - Hoàn thành những công việc khác tùy thuộc theo yêu cầu kinh doanh của Công ty và theo quyết định của Ban Giám đốc (và các cá nhân được bổ nhiệm hoặc ủy quyền phụ trách).',
 'Toàn thời gian','Từ ngày thứ 2 đến sáng ngày thứ 7:
 - Buổi sáng: 8h00 – 12h00
 - Buổi chiều: 13h30 – 17h30
 - Sáng ngày thứ 7: Làm việc từ 08h00 đến 12h00', null,5000000,'Theo đánh giá của quản lý',null,'Theo quy định của phòng ban, công ty',40000000,
'Tùy từng vị trí, người lao động được hưởng theo quy định của công ty','Chuyển khoản','Được trả lương vào ngày cuối tháng','1,5 ngày (Chiều Thứ 7 và ngày Chủ nhật)',
null,'Số 15 Nguyễn Kiệm, phường 2, quận GV TPHCM','Số 15 Nguyễn Kiệm, phường 2, quận GV TPHCM',
'Thiết bị và công cụ làm việc sẽ được Công ty cấp phát tùy theo nhu cầu của công việc',null,null,
'Thực hiện theo Nghị định của Chính phủ quy định mức lương tối thiểu theo vùng, theo khu vực',
'Điều kiện an toàn và vệ sinh lao động tại nơi làm việc theo quy định của pháp luật hiện hành',
'Theo quy định của Công ty và yêu cầu công việc. Trong trường hợp CBNV được cử đi đào tạo thì nhân viên phải hoàn thành khoá học đúng thời hạn, phải cam kết sẽ phục vụ lâu dài cho Công ty sau khi kết thúc khoá học và được hưởng nguyên lương, các quyền lợi khác được  hưởng như người đi làm',
null,null,'2025-01-01','2025-01-01',1,null,0,NOW());
INSERT INTO `hrss`.`Contracts`
(`ContractNo`,`EmployeeCode`,`DepartmentCode`,`PositionCode`,`ContractTypeCode`,`ContractDate`,`StartDate`,`EndDate`,
`JobDescription`,`WorkingTime`,`WorkingDays`,`AdditionalDuties`,`ResponsibilityAllowance`,`PerformanceAllowance`,
`OtherAllowances`,`EffectiveSalary`,`GrossSalary`,`TravelAllowance`,`SalaryPaymentMethod`,`SalaryPaymentTime`,`WeeklyLeaveSchedule`,
`OtherBenefits`,`ContractLocation`,`WorkLocation`,`WorkingTools`,`Transportation`,`BonusPolicy`,
`SalaryIncreasePolicy`,`LaborProtection`,`TrainingPolicy`,`SocialInsurance`,`HealthInsurance`,
`SignDate`,`EffectiveDate`,`IsSigned`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES
('000022','DEFAULT02','DEFAULT','DEFAULT','0Y','2025-01-01',
'2025-01-01','2075-01-01','- Thực hiện công việc theo đúng chức danh chuyên môn của mình dưới sự quản lý, điều hành của Ban Giám đốc (và các cá nhân được bổ nhiệm hoặc ủy quyền phụ trách).
 - Phối hợp cùng với các bộ phận, phòng ban khác trong Công ty để phát huy tối đa hiệu quả công việc.
 - Hoàn thành những công việc khác tùy thuộc theo yêu cầu kinh doanh của Công ty và theo quyết định của Ban Giám đốc (và các cá nhân được bổ nhiệm hoặc ủy quyền phụ trách).',
 'Toàn thời gian','Từ ngày thứ 2 đến sáng ngày thứ 7:
 - Buổi sáng: 8h00 – 12h00
 - Buổi chiều: 13h30 – 17h30
 - Sáng ngày thứ 7: Làm việc từ 08h00 đến 12h00', null,5000000,'Theo đánh giá của quản lý',null,'Theo quy định của phòng ban, công ty',40000000,
'Tùy từng vị trí, người lao động được hưởng theo quy định của công ty','Chuyển khoản','Được trả lương vào ngày cuối tháng','1,5 ngày (Chiều Thứ 7 và ngày Chủ nhật)',
null,'Số 15 Nguyễn Kiệm, phường 2, quận GV TPHCM','Số 15 Nguyễn Kiệm, phường 2, quận GV TPHCM',
'Thiết bị và công cụ làm việc sẽ được Công ty cấp phát tùy theo nhu cầu của công việc',null,null,
'Thực hiện theo Nghị định của Chính phủ quy định mức lương tối thiểu theo vùng, theo khu vực',
'Điều kiện an toàn và vệ sinh lao động tại nơi làm việc theo quy định của pháp luật hiện hành',
'Theo quy định của Công ty và yêu cầu công việc. Trong trường hợp CBNV được cử đi đào tạo thì nhân viên phải hoàn thành khoá học đúng thời hạn, phải cam kết sẽ phục vụ lâu dài cho Công ty sau khi kết thúc khoá học và được hưởng nguyên lương, các quyền lợi khác được  hưởng như người đi làm',
null,null,'2025-01-01','2025-01-01',1,null,0,NOW());
INSERT INTO `hrss`.`Contracts`
(`ContractNo`,`EmployeeCode`,`DepartmentCode`,`PositionCode`,`ContractTypeCode`,`ContractDate`,`StartDate`,`EndDate`,
`JobDescription`,`WorkingTime`,`WorkingDays`,`AdditionalDuties`,`ResponsibilityAllowance`,`PerformanceAllowance`,
`OtherAllowances`,`EffectiveSalary`,`GrossSalary`,`TravelAllowance`,`SalaryPaymentMethod`,`SalaryPaymentTime`,`WeeklyLeaveSchedule`,
`OtherBenefits`,`ContractLocation`,`WorkLocation`,`WorkingTools`,`Transportation`,`BonusPolicy`,
`SalaryIncreasePolicy`,`LaborProtection`,`TrainingPolicy`,`SocialInsurance`,`HealthInsurance`,
`SignDate`,`EffectiveDate`,`IsSigned`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES
('00003','DEFAULT03','DEFAULT','DEFAULT','0Y','2025-01-01',
'2025-01-01','2075-01-01','- Thực hiện công việc theo đúng chức danh chuyên môn của mình dưới sự quản lý, điều hành của Ban Giám đốc (và các cá nhân được bổ nhiệm hoặc ủy quyền phụ trách).
 - Phối hợp cùng với các bộ phận, phòng ban khác trong Công ty để phát huy tối đa hiệu quả công việc.
 - Hoàn thành những công việc khác tùy thuộc theo yêu cầu kinh doanh của Công ty và theo quyết định của Ban Giám đốc (và các cá nhân được bổ nhiệm hoặc ủy quyền phụ trách).',
 'Toàn thời gian','Từ ngày thứ 2 đến sáng ngày thứ 7:
 - Buổi sáng: 8h00 – 12h00
 - Buổi chiều: 13h30 – 17h30
 - Sáng ngày thứ 7: Làm việc từ 08h00 đến 12h00', null,2000000,'Theo đánh giá của quản lý',null,'Theo quy định của phòng ban, công ty',25000000,
'Tùy từng vị trí, người lao động được hưởng theo quy định của công ty','Chuyển khoản','Được trả lương vào ngày cuối tháng','1,5 ngày (Chiều Thứ 7 và ngày Chủ nhật)',
null,'Số 15 Nguyễn Kiệm, phường 2, quận GV TPHCM','Số 15 Nguyễn Kiệm, phường 2, quận GV TPHCM',
'Thiết bị và công cụ làm việc sẽ được Công ty cấp phát tùy theo nhu cầu của công việc',null,null,
'Thực hiện theo Nghị định của Chính phủ quy định mức lương tối thiểu theo vùng, theo khu vực',
'Điều kiện an toàn và vệ sinh lao động tại nơi làm việc theo quy định của pháp luật hiện hành',
'Theo quy định của Công ty và yêu cầu công việc. Trong trường hợp CBNV được cử đi đào tạo thì nhân viên phải hoàn thành khoá học đúng thời hạn, phải cam kết sẽ phục vụ lâu dài cho Công ty sau khi kết thúc khoá học và được hưởng nguyên lương, các quyền lợi khác được  hưởng như người đi làm',
null,null,'2025-01-01','2025-01-01',0,null,0,NOW());
INSERT INTO `hrss`.`Contracts`
(`ContractNo`,`EmployeeCode`,`DepartmentCode`,`PositionCode`,`ContractTypeCode`,`ContractDate`,`StartDate`,`EndDate`,
`JobDescription`,`WorkingTime`,`WorkingDays`,`AdditionalDuties`,`ResponsibilityAllowance`,`PerformanceAllowance`,
`OtherAllowances`,`EffectiveSalary`,`GrossSalary`,`TravelAllowance`,`SalaryPaymentMethod`,`SalaryPaymentTime`,`WeeklyLeaveSchedule`,
`OtherBenefits`,`ContractLocation`,`WorkLocation`,`WorkingTools`,`Transportation`,`BonusPolicy`,
`SalaryIncreasePolicy`,`LaborProtection`,`TrainingPolicy`,`SocialInsurance`,`HealthInsurance`,
`SignDate`,`EffectiveDate`,`IsSigned`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES
('00004','DEFAULT04','DEFAULT','DEFAULT','0Y','2025-01-01',
'2025-01-01','2075-01-01','- Thực hiện công việc theo đúng chức danh chuyên môn của mình dưới sự quản lý, điều hành của Ban Giám đốc (và các cá nhân được bổ nhiệm hoặc ủy quyền phụ trách).
 - Phối hợp cùng với các bộ phận, phòng ban khác trong Công ty để phát huy tối đa hiệu quả công việc.
 - Hoàn thành những công việc khác tùy thuộc theo yêu cầu kinh doanh của Công ty và theo quyết định của Ban Giám đốc (và các cá nhân được bổ nhiệm hoặc ủy quyền phụ trách).',
 'Toàn thời gian','Từ ngày thứ 2 đến sáng ngày thứ 7:
 - Buổi sáng: 8h00 – 12h00
 - Buổi chiều: 13h30 – 17h30
 - Sáng ngày thứ 7: Làm việc từ 08h00 đến 12h00', null,5000000,'Theo đánh giá của quản lý',null,'Theo quy định của phòng ban, công ty',20000000,
'Tùy từng vị trí, người lao động được hưởng theo quy định của công ty','Chuyển khoản','Được trả lương vào ngày cuối tháng','1,5 ngày (Chiều Thứ 7 và ngày Chủ nhật)',
null,'Số 15 Nguyễn Kiệm, phường 2, quận GV TPHCM','Số 15 Nguyễn Kiệm, phường 2, quận GV TPHCM',
'Thiết bị và công cụ làm việc sẽ được Công ty cấp phát tùy theo nhu cầu của công việc',null,null,
'Thực hiện theo Nghị định của Chính phủ quy định mức lương tối thiểu theo vùng, theo khu vực',
'Điều kiện an toàn và vệ sinh lao động tại nơi làm việc theo quy định của pháp luật hiện hành',
'Theo quy định của Công ty và yêu cầu công việc. Trong trường hợp CBNV được cử đi đào tạo thì nhân viên phải hoàn thành khoá học đúng thời hạn, phải cam kết sẽ phục vụ lâu dài cho Công ty sau khi kết thúc khoá học và được hưởng nguyên lương, các quyền lợi khác được  hưởng như người đi làm',
null,null,'2025-01-01','2025-01-01',1,null,0,NOW());
INSERT INTO `hrss`.`Contracts`
(`ContractNo`,`EmployeeCode`,`DepartmentCode`,`PositionCode`,`ContractTypeCode`,`ContractDate`,`StartDate`,`EndDate`,
`JobDescription`,`WorkingTime`,`WorkingDays`,`AdditionalDuties`,`ResponsibilityAllowance`,`PerformanceAllowance`,
`OtherAllowances`,`EffectiveSalary`,`GrossSalary`,`TravelAllowance`,`SalaryPaymentMethod`,`SalaryPaymentTime`,`WeeklyLeaveSchedule`,
`OtherBenefits`,`ContractLocation`,`WorkLocation`,`WorkingTools`,`Transportation`,`BonusPolicy`,
`SalaryIncreasePolicy`,`LaborProtection`,`TrainingPolicy`,`SocialInsurance`,`HealthInsurance`,
`SignDate`,`EffectiveDate`,`IsSigned`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES
('00005','DEFAULT05','DEFAULT','DEFAULT','0Y','2025-01-01',
'2025-01-01','2075-01-01','- Thực hiện công việc theo đúng chức danh chuyên môn của mình dưới sự quản lý, điều hành của Ban Giám đốc (và các cá nhân được bổ nhiệm hoặc ủy quyền phụ trách).
 - Phối hợp cùng với các bộ phận, phòng ban khác trong Công ty để phát huy tối đa hiệu quả công việc.
 - Hoàn thành những công việc khác tùy thuộc theo yêu cầu kinh doanh của Công ty và theo quyết định của Ban Giám đốc (và các cá nhân được bổ nhiệm hoặc ủy quyền phụ trách).',
 'Toàn thời gian','Từ ngày thứ 2 đến sáng ngày thứ 7:
 - Buổi sáng: 8h00 – 12h00
 - Buổi chiều: 13h30 – 17h30
 - Sáng ngày thứ 7: Làm việc từ 08h00 đến 12h00', null,5000000,'Theo đánh giá của quản lý',null,'Theo quy định của phòng ban, công ty',32000000,
'Tùy từng vị trí, người lao động được hưởng theo quy định của công ty','Chuyển khoản','Được trả lương vào ngày cuối tháng','1,5 ngày (Chiều Thứ 7 và ngày Chủ nhật)',
null,'Số 15 Nguyễn Kiệm, phường 2, quận GV TPHCM','Số 15 Nguyễn Kiệm, phường 2, quận GV TPHCM',
'Thiết bị và công cụ làm việc sẽ được Công ty cấp phát tùy theo nhu cầu của công việc',null,null,
'Thực hiện theo Nghị định của Chính phủ quy định mức lương tối thiểu theo vùng, theo khu vực',
'Điều kiện an toàn và vệ sinh lao động tại nơi làm việc theo quy định của pháp luật hiện hành',
'Theo quy định của Công ty và yêu cầu công việc. Trong trường hợp CBNV được cử đi đào tạo thì nhân viên phải hoàn thành khoá học đúng thời hạn, phải cam kết sẽ phục vụ lâu dài cho Công ty sau khi kết thúc khoá học và được hưởng nguyên lương, các quyền lợi khác được  hưởng như người đi làm',
null,null,'2025-01-01','2025-01-01',1,null,0,NOW());
INSERT INTO `hrss`.`Contracts`
(`ContractNo`,`EmployeeCode`,`DepartmentCode`,`PositionCode`,`ContractTypeCode`,`ContractDate`,`StartDate`,`EndDate`,
`JobDescription`,`WorkingTime`,`WorkingDays`,`AdditionalDuties`,`ResponsibilityAllowance`,`PerformanceAllowance`,
`OtherAllowances`,`EffectiveSalary`,`GrossSalary`,`TravelAllowance`,`SalaryPaymentMethod`,`SalaryPaymentTime`,`WeeklyLeaveSchedule`,
`OtherBenefits`,`ContractLocation`,`WorkLocation`,`WorkingTools`,`Transportation`,`BonusPolicy`,
`SalaryIncreasePolicy`,`LaborProtection`,`TrainingPolicy`,`SocialInsurance`,`HealthInsurance`,
`SignDate`,`EffectiveDate`,`IsSigned`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES
('00006','DEFAULT06','DEFAULT','DEFAULT','0Y','2025-01-01',
'2025-01-01','2075-01-01','- Thực hiện công việc theo đúng chức danh chuyên môn của mình dưới sự quản lý, điều hành của Ban Giám đốc (và các cá nhân được bổ nhiệm hoặc ủy quyền phụ trách).
 - Phối hợp cùng với các bộ phận, phòng ban khác trong Công ty để phát huy tối đa hiệu quả công việc.
 - Hoàn thành những công việc khác tùy thuộc theo yêu cầu kinh doanh của Công ty và theo quyết định của Ban Giám đốc (và các cá nhân được bổ nhiệm hoặc ủy quyền phụ trách).',
 'Toàn thời gian','Từ ngày thứ 2 đến sáng ngày thứ 7:
 - Buổi sáng: 8h00 – 12h00
 - Buổi chiều: 13h30 – 17h30
 - Sáng ngày thứ 7: Làm việc từ 08h00 đến 12h00', null,3200000,'Theo đánh giá của quản lý',null,'Theo quy định của phòng ban, công ty',44000000,
'Tùy từng vị trí, người lao động được hưởng theo quy định của công ty','Chuyển khoản','Được trả lương vào ngày cuối tháng','1,5 ngày (Chiều Thứ 7 và ngày Chủ nhật)',
null,'Số 15 Nguyễn Kiệm, phường 2, quận GV TPHCM','Số 15 Nguyễn Kiệm, phường 2, quận GV TPHCM',
'Thiết bị và công cụ làm việc sẽ được Công ty cấp phát tùy theo nhu cầu của công việc',null,null,
'Thực hiện theo Nghị định của Chính phủ quy định mức lương tối thiểu theo vùng, theo khu vực',
'Điều kiện an toàn và vệ sinh lao động tại nơi làm việc theo quy định của pháp luật hiện hành',
'Theo quy định của Công ty và yêu cầu công việc. Trong trường hợp CBNV được cử đi đào tạo thì nhân viên phải hoàn thành khoá học đúng thời hạn, phải cam kết sẽ phục vụ lâu dài cho Công ty sau khi kết thúc khoá học và được hưởng nguyên lương, các quyền lợi khác được  hưởng như người đi làm',
null,null,'2025-01-01','2025-01-01',1,null,0,NOW());
INSERT INTO `hrss`.`Contracts`
(`ContractNo`,`EmployeeCode`,`DepartmentCode`,`PositionCode`,`ContractTypeCode`,`ContractDate`,`StartDate`,`EndDate`,
`JobDescription`,`WorkingTime`,`WorkingDays`,`AdditionalDuties`,`ResponsibilityAllowance`,`PerformanceAllowance`,
`OtherAllowances`,`EffectiveSalary`,`GrossSalary`,`TravelAllowance`,`SalaryPaymentMethod`,`SalaryPaymentTime`,`WeeklyLeaveSchedule`,
`OtherBenefits`,`ContractLocation`,`WorkLocation`,`WorkingTools`,`Transportation`,`BonusPolicy`,
`SalaryIncreasePolicy`,`LaborProtection`,`TrainingPolicy`,`SocialInsurance`,`HealthInsurance`,
`SignDate`,`EffectiveDate`,`IsSigned`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES
('00007','DEFAULT07','DEFAULT','DEFAULT','0Y','2025-01-01',
'2025-01-01','2075-01-01','- Thực hiện công việc theo đúng chức danh chuyên môn của mình dưới sự quản lý, điều hành của Ban Giám đốc (và các cá nhân được bổ nhiệm hoặc ủy quyền phụ trách).
 - Phối hợp cùng với các bộ phận, phòng ban khác trong Công ty để phát huy tối đa hiệu quả công việc.
 - Hoàn thành những công việc khác tùy thuộc theo yêu cầu kinh doanh của Công ty và theo quyết định của Ban Giám đốc (và các cá nhân được bổ nhiệm hoặc ủy quyền phụ trách).',
 'Toàn thời gian','Từ ngày thứ 2 đến sáng ngày thứ 7:
 - Buổi sáng: 8h00 – 12h00
 - Buổi chiều: 13h30 – 17h30
 - Sáng ngày thứ 7: Làm việc từ 08h00 đến 12h00', null,5000000,'Theo đánh giá của quản lý',null,'Theo quy định của phòng ban, công ty',39000000,
'Tùy từng vị trí, người lao động được hưởng theo quy định của công ty','Chuyển khoản','Được trả lương vào ngày cuối tháng','1,5 ngày (Chiều Thứ 7 và ngày Chủ nhật)',
null,'Số 15 Nguyễn Kiệm, phường 2, quận GV TPHCM','Số 15 Nguyễn Kiệm, phường 2, quận GV TPHCM',
'Thiết bị và công cụ làm việc sẽ được Công ty cấp phát tùy theo nhu cầu của công việc',null,null,
'Thực hiện theo Nghị định của Chính phủ quy định mức lương tối thiểu theo vùng, theo khu vực',
'Điều kiện an toàn và vệ sinh lao động tại nơi làm việc theo quy định của pháp luật hiện hành',
'Theo quy định của Công ty và yêu cầu công việc. Trong trường hợp CBNV được cử đi đào tạo thì nhân viên phải hoàn thành khoá học đúng thời hạn, phải cam kết sẽ phục vụ lâu dài cho Công ty sau khi kết thúc khoá học và được hưởng nguyên lương, các quyền lợi khác được  hưởng như người đi làm',
null,null,'2025-01-01','2025-01-01',1,null,0,NOW());
INSERT INTO `hrss`.`Contracts`
(`ContractNo`,`EmployeeCode`,`DepartmentCode`,`PositionCode`,`ContractTypeCode`,`ContractDate`,`StartDate`,`EndDate`,
`JobDescription`,`WorkingTime`,`WorkingDays`,`AdditionalDuties`,`ResponsibilityAllowance`,`PerformanceAllowance`,
`OtherAllowances`,`EffectiveSalary`,`GrossSalary`,`TravelAllowance`,`SalaryPaymentMethod`,`SalaryPaymentTime`,`WeeklyLeaveSchedule`,
`OtherBenefits`,`ContractLocation`,`WorkLocation`,`WorkingTools`,`Transportation`,`BonusPolicy`,
`SalaryIncreasePolicy`,`LaborProtection`,`TrainingPolicy`,`SocialInsurance`,`HealthInsurance`,
`SignDate`,`EffectiveDate`,`IsSigned`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES
('00008','DEFAULT08','DEFAULT','DEFAULT','0Y','2025-01-01',
'2025-01-01','2075-01-01','- Thực hiện công việc theo đúng chức danh chuyên môn của mình dưới sự quản lý, điều hành của Ban Giám đốc (và các cá nhân được bổ nhiệm hoặc ủy quyền phụ trách).
 - Phối hợp cùng với các bộ phận, phòng ban khác trong Công ty để phát huy tối đa hiệu quả công việc.
 - Hoàn thành những công việc khác tùy thuộc theo yêu cầu kinh doanh của Công ty và theo quyết định của Ban Giám đốc (và các cá nhân được bổ nhiệm hoặc ủy quyền phụ trách).',
 'Toàn thời gian','Từ ngày thứ 2 đến sáng ngày thứ 7:
 - Buổi sáng: 8h00 – 12h00
 - Buổi chiều: 13h30 – 17h30
 - Sáng ngày thứ 7: Làm việc từ 08h00 đến 12h00', null,5000000,'Theo đánh giá của quản lý',null,'Theo quy định của phòng ban, công ty',42000000,
'Tùy từng vị trí, người lao động được hưởng theo quy định của công ty','Chuyển khoản','Được trả lương vào ngày cuối tháng','1,5 ngày (Chiều Thứ 7 và ngày Chủ nhật)',
null,'Số 15 Nguyễn Kiệm, phường 2, quận GV TPHCM','Số 15 Nguyễn Kiệm, phường 2, quận GV TPHCM',
'Thiết bị và công cụ làm việc sẽ được Công ty cấp phát tùy theo nhu cầu của công việc',null,null,
'Thực hiện theo Nghị định của Chính phủ quy định mức lương tối thiểu theo vùng, theo khu vực',
'Điều kiện an toàn và vệ sinh lao động tại nơi làm việc theo quy định của pháp luật hiện hành',
'Theo quy định của Công ty và yêu cầu công việc. Trong trường hợp CBNV được cử đi đào tạo thì nhân viên phải hoàn thành khoá học đúng thời hạn, phải cam kết sẽ phục vụ lâu dài cho Công ty sau khi kết thúc khoá học và được hưởng nguyên lương, các quyền lợi khác được  hưởng như người đi làm',
null,null,'2025-01-01','2025-01-01',1,null,0,NOW());
INSERT INTO `hrss`.`Contracts`
(`ContractNo`,`EmployeeCode`,`DepartmentCode`,`PositionCode`,`ContractTypeCode`,`ContractDate`,`StartDate`,`EndDate`,
`JobDescription`,`WorkingTime`,`WorkingDays`,`AdditionalDuties`,`ResponsibilityAllowance`,`PerformanceAllowance`,
`OtherAllowances`,`EffectiveSalary`,`GrossSalary`,`TravelAllowance`,`SalaryPaymentMethod`,`SalaryPaymentTime`,`WeeklyLeaveSchedule`,
`OtherBenefits`,`ContractLocation`,`WorkLocation`,`WorkingTools`,`Transportation`,`BonusPolicy`,
`SalaryIncreasePolicy`,`LaborProtection`,`TrainingPolicy`,`SocialInsurance`,`HealthInsurance`,
`SignDate`,`EffectiveDate`,`IsSigned`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES
('00009','DEFAULT09','DEFAULT','DEFAULT','0Y','2025-01-01',
'2025-01-01','2075-01-01','- Thực hiện công việc theo đúng chức danh chuyên môn của mình dưới sự quản lý, điều hành của Ban Giám đốc (và các cá nhân được bổ nhiệm hoặc ủy quyền phụ trách).
 - Phối hợp cùng với các bộ phận, phòng ban khác trong Công ty để phát huy tối đa hiệu quả công việc.
 - Hoàn thành những công việc khác tùy thuộc theo yêu cầu kinh doanh của Công ty và theo quyết định của Ban Giám đốc (và các cá nhân được bổ nhiệm hoặc ủy quyền phụ trách).',
 'Toàn thời gian','Từ ngày thứ 2 đến sáng ngày thứ 7:
 - Buổi sáng: 8h00 – 12h00
 - Buổi chiều: 13h30 – 17h30
 - Sáng ngày thứ 7: Làm việc từ 08h00 đến 12h00', null,5000000,'Theo đánh giá của quản lý',null,'Theo quy định của phòng ban, công ty',36000000,
'Tùy từng vị trí, người lao động được hưởng theo quy định của công ty','Chuyển khoản','Được trả lương vào ngày cuối tháng','1,5 ngày (Chiều Thứ 7 và ngày Chủ nhật)',
null,'Số 15 Nguyễn Kiệm, phường 2, quận GV TPHCM','Số 15 Nguyễn Kiệm, phường 2, quận GV TPHCM',
'Thiết bị và công cụ làm việc sẽ được Công ty cấp phát tùy theo nhu cầu của công việc',null,null,
'Thực hiện theo Nghị định của Chính phủ quy định mức lương tối thiểu theo vùng, theo khu vực',
'Điều kiện an toàn và vệ sinh lao động tại nơi làm việc theo quy định của pháp luật hiện hành',
'Theo quy định của Công ty và yêu cầu công việc. Trong trường hợp CBNV được cử đi đào tạo thì nhân viên phải hoàn thành khoá học đúng thời hạn, phải cam kết sẽ phục vụ lâu dài cho Công ty sau khi kết thúc khoá học và được hưởng nguyên lương, các quyền lợi khác được  hưởng như người đi làm',
null,null,'2025-01-01','2025-01-01',1,null,0,NOW());

INSERT INTO `hrss`.`LeaveTypes`(`LeaveCode`,`LeaveName`,`IsPaid`,`IsSocialInsurance`,`AllowedDaysPerYear`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('AL','Phép năm',1,0,12,null,0,NOW());
INSERT INTO `hrss`.`LeaveTypes`(`LeaveCode`,`LeaveName`,`IsPaid`,`IsSocialInsurance`,`AllowedDaysPerYear`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('SL','Nghỉ bệnh',0,1,5,null,0,NOW());
INSERT INTO `hrss`.`LeaveTypes`(`LeaveCode`,`LeaveName`,`IsPaid`,`IsSocialInsurance`,`AllowedDaysPerYear`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('KSL','Nghỉ con ốm',0,1,5,null,0,NOW());
INSERT INTO `hrss`.`LeaveTypes`(`LeaveCode`,`LeaveName`,`IsPaid`,`IsSocialInsurance`,`AllowedDaysPerYear`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('NS','Nghỉ không lương',0,0,5,null,0,NOW());

INSERT INTO `hrss`.`Companies`
(`CompanyNo`,`CompanyName`,`TaxCode`,`BankAccountNumber`,`BankName`,`Address`,
`PhoneNumber`,`RepresentativeName`,`RepresentativePosition`,`RepresentativeGender`,
`RepresentativeNationality`,`RepresentativeTaxCode`,`RepresentativeBankAccount`,
`RepresentativeBankName`,`RepresentativePhone`,`RepresentativeEmail`,`Description`,
`CreatedBy`,`CreatedAt`)
VALUES
('00001','Công ty TNHH Đại Hưng','09765434332345433','1234567891002024',
'Ngân hàng thương mại XNK Eximbank','B675 Nguyễn Văn Tâm, Phường 2, Quận 10, TPHCM',
'0987977543','Trần Văn Tâm','Giám đốc nhân sự','Male','Việt Nam','45443456545343',
'98098493048381300','Ngân hàng thương mại XNK Eximbank','0899766578','tamtr@daihung.vn',null,
0,NOW());

INSERT INTO `hrss`.`OvertimeTypes`(`OvertimeCode`,`OvertimeName`,`OvertimeRate`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('WK','Tăng ca cuối tuần',2,null,0,NOW());
INSERT INTO `hrss`.`OvertimeTypes`(`OvertimeCode`,`OvertimeName`,`OvertimeRate`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('Holiday','Tăng ca ngày lễ',3,null,0,NOW());
INSERT INTO `hrss`.`OvertimeTypes`(`OvertimeCode`,`OvertimeName`,`OvertimeRate`,`Description`,`CreatedBy`,`CreatedAt`)
VALUES('Night','Tăng ca buổi tối',1.5,null,0,NOW());