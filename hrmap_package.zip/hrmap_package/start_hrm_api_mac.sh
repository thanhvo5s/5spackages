# Chạy file thực thi api-mac (giả sử là tương đương api-win.exe)
./dist/hrmapi-macos

# Dừng màn hình bằng cách chờ người dùng nhấn Enter
read -p "Press Enter to continue..."